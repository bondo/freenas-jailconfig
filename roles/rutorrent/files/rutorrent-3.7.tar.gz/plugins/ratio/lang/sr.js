﻿/*
 * PLUGIN RATIO
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.ratios		= "Односне групе";
 theUILang.ratio		= "Односна група";
 theUILang.mnuRatio		= "Поставити односну групу";
 theUILang.mnuRatioUnlimited	= "Нема односа";
 theUILang.ratioName		= "Име";
 theUILang.minRatio		= "Минимално";
 theUILang.maxRatio		= "Максимално";
 theUILang.ratioUpload		= "Узтовар";
 theUILang.ratioAction		= "Акција";
 theUILang.ratioStop		= "Зауставити";
 theUILang.ratioStopAndRemove	= "Зауставити и обрисати групу";
 theUILang.ratioErase		= "Уклонити";
 theUILang.ratioEraseData	= "Remove data";
 theUILang.maxTime		= "Time";
 theUILang.ratioDefault 	= "Default ratio group";
 theUILang.setThrottleTo	= "Set channel to";

thePlugins.get("ratio").langLoaded();