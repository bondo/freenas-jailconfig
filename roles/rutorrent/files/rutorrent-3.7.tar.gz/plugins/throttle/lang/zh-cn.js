﻿/*
 * PLUGIN THROTTLE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.throttles		= "通道";
 theUILang.throttle		= "通道";
 theUILang.mnuThrottle		= "设置通道";
 theUILang.mnuUnlimited 	= "无通道";
 theUILang.channelName		= "名称";
 theUILang.channelDefault	= "Default channel";

thePlugins.get("throttle").langLoaded();