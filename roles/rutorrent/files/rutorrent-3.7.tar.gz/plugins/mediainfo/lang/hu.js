﻿/*
 * PLUGIN MEDIAINFO
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";