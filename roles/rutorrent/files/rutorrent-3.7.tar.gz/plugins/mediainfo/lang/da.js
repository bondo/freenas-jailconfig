﻿/*
 * PLUGIN MEDIAINFO
 *
 * Danish language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";