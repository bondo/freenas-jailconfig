﻿/*
 * PLUGIN MEDIAINFO
 *
 * Slovak language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";