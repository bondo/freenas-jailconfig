﻿/*
 * PLUGIN RETRACKERS
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.retrackers		= "Đổi máy theo dõi";
 theUILang.retrackersAdd	= "Thêm thông báo";
 theUILang.retrackersDel	= "Bỏ thông báo";
 theUILang.dontAddToPrivate	= "Không áp dụng với torrent riêng tư";
 theUILang.addToBegin		= "Thêm thông báo từ đầu danh sách máy theo dõi";

thePlugins.get("retrackers").langLoaded();