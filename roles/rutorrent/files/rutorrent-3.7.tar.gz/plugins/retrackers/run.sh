#!/bin/sh
cd `dirname $0`
$1 update.php $2 $3 &