<?php
	require_once( './ratios.php' );
		
	cachedEcho(getRatiosStat(),"application/javascript");
