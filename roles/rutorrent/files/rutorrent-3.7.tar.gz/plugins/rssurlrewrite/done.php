<?php

rTorrentSettings::get()->unregisterEventHook("rssurlrewrite","RSSFetched");
