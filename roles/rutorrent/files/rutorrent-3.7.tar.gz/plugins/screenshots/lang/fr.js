﻿/*
 * PLUGIN SCREENSHOTS
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.exFFMPEG		= "Screenshots";
 theUILang.exFrameWidth 	= "Taille de l'image";
 theUILang.exFramesCount	= "Nombre d'images";
 theUILang.exStartOffset	= "Image de démarrage";
 theUILang.exBetween		= "Temps entre les images";
 theUILang.exSave		= "Enregistrer";
 theUILang.exSaveAll		= "Enregistrer tout";
 theUILang.exScreenshot 	= "Screenshot";
 theUILang.exPlayInterval	= "Intevalle du diaporama";
 theUILang.exImageFormat	= "Format de l'image";

thePlugins.get("screenshots").langLoaded();