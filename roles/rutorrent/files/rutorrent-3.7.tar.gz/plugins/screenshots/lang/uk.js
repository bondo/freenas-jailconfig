﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.exFFMPEG		= "Знімки екрана";
 theUILang.exFrameWidth 	= "Ширина кадра";
 theUILang.exFramesCount	= "Кількість кадрів";
 theUILang.exStartOffset	= "Початкове зміщення";
 theUILang.exBetween		= "Час між кадрами";
 theUILang.exSave		= "Зберегти";
 theUILang.exSaveAll		= "Зберегти все";
 theUILang.exScreenshot 	= "Знімок екрана";
 theUILang.exPlayInterval	= "Інтервал показу";
 theUILang.exImageFormat	= "Формат";

thePlugins.get("screenshots").langLoaded();