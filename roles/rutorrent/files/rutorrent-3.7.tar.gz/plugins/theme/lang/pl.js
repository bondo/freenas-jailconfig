﻿/*
 * PLUGIN THEME
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Kompozycja";

thePlugins.get("theme").langLoaded();