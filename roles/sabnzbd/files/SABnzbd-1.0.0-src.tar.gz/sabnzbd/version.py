# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "1.0.0"
__baseline__ = "a58bb385f57d0c5c8a92b7e3ea082d776363767e"
